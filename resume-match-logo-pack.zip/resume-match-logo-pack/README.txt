Resume Match logo pack

Files:
- resume-match-logo-horizontal.svg  -> primary logo for header/site
- resume-match-icon.svg             -> app icon / favicon / compact use
- resume-match-logo-monochrome.svg  -> one-color horizontal version
- resume-match-icon-monochrome.svg  -> one-color compact icon

Suggested project folder:
public/brand/

Example Next.js path:
/public/brand/resume-match-logo-horizontal.svg

Recommended colors:
Brand pink: #FF4F79
Brand pink dark: #FF2F67
Ink: #171717 / #171A22
Canvas: #F7F7F5
